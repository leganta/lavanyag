package applyCoupons;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^valid customers who got email$")
	public void valid_customers_who_got_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^customers click on Apply coupons$")
	public void customers_click_on_Apply_coupons() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Show the coupons for the customers$")
	public void show_the_coupons_for_the_customers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^calculate the price for the given item$")
	public void calculate_the_price_for_the_given_item() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Get the Final Bill$")
	public void get_the_Final_Bill() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
